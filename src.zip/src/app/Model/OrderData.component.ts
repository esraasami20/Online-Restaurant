import { Menu } from "./Data.component";

export interface OrderData {
  menus: Menu[];
  customer_Name: string;
  customer_Phone: number;
  customer_Email: string;
  customer_Address:string;
}

